/**
 * \file TIMER1.c
 * \brief TIMER
 * \author Xavier & Romain
 * \version 0.1
 * \date 1 avril 2012
 */

#include "TIMER.h"
#include "ADC.h"
#include "PWM.h"
#include "IO.h"
#include "UART.h"

void TIMER1_Init ()
{
    T1CON=0x00;
    TMR1=0x00;          // reset du timer

    T1CONbits.TCS=0b0;      // utilisation de l'horloge interne (Fcy)  (16 MHz)
    T1CONbits.TCKPS=0b11;   // prescaler par 256 ==> Fcy/256 = 62,5 khz

    PR1=62;                 // pour une p�riode de timer1 : 1ms

    // r�glage interruption pour g�n�rer l'�v�nement pour ADC
    IPC0bits.T1IP = 2;   // Priorit� de l'interruption
    IFS0bits.T1IF = 0;      // Clear Interrupt Flag
    IEC0bits.T1IE = 1;      // Autorisation de l'interruption Timer1
    T1CONbits.TON=0b1;      // Timer1 lanc�
}


// Tension d'offset
#define DEF_VREF 1524
const short Vref = DEF_VREF;        // 1.77 * 4096.0 / 5.0;

inline void fonctionAnalog_T1Interrupt(void)
{
    short Mesure;
    unsigned short DutyCycle;
// ==========================================
// Conditionnement du signal
// ==========================================
    // Ajout de l'inverseur pour avance de phase
    short ADC;
    ADC  = ADC_Convert(POT1);   // Acquisition de la mesure
    Mesure = Vref - ADC;    // Suppression de l'offset
    MESURE = Mesure;        // Mesure � envoyer � l'IHM
    // Protection
    if (Mesure > 950 || Mesure < -700)
        goto protection;

    // limitation PWM � 80%
    if (Mesure > 408)
        Mesure = 408;
    if (Mesure < -408)
        Mesure = -408; 

// ==========================================
// Pilotage de la PWM
// ==========================================
    if (Mesure < 0)
    {
        DutyCycle = - Mesure;
        MODE1 = 0;
        MODE2 = 1;
    }
    else
    {
        DutyCycle = Mesure;
        MODE1 = 1;
        MODE2 = 0;
    }
    PWM_SetDutyCycle(DutyCycle);
    return;

    protection :
        PWM_SetDutyCycle(0);
    return;
}


// Initialisation pour le premier calcule
float input[2] = {0};
float output[2] = {0};

inline void fonctionNumerique_T1Interrupt(void)
{
    short ADC, DutyCycle;
// Num�rise la position et check la plage
    ADC = Vref - ADC_Convert(POT1);
    if (ADC > 950 || ADC < -700)
        goto protection;
// Calcule la fonction d'asservissement
    input[0] = GAININ * (float) ADC;
    output[0] = Xk * input[0] - Xk1 * input[1] + Yk1 * output[1];
// Veillessement des variables
    output[1] = output[0];
    input[1] = input[0];
// Gain de sortie
    output[0] *= GAINOUT;
    if (output[0] > 408.0f) output[0] = 408.0f;
    if (output[0] < -408.0f) output[0] = -408.0f;  //limitation a 80% de la PWM

// ==========================================
// Pilotage de la PWM
// ==========================================
    if (output[0] < 0)
    {
        DutyCycle = - output[0];
        MODE1 = 0;
        MODE2 = 1;
    }
    else
    {
        DutyCycle = output[0];
        MODE1 = 1;
        MODE2 = 0;
    }
    PWM_SetDutyCycle(DutyCycle);
    return;

protection :
    PWM_SetDutyCycle(0);
    return;
}

#define MI4     24270,24270, 2      // 16000000/659.26
#define SOL4    20408,20408, 2      // 16000000/784
#define SOL3    40816,40816         // 16000000/392
#define DO4     30578,30578, 2      // 16000000/523,25
#define TM      2, 2                   // Temps mort
#define NBNOTE  32

const unsigned short note[NBNOTE] = {MI4, MI4,TM, MI4,TM,DO4,MI4,TM, SOL4,TM,TM, SOL3, SOL3};
inline void fonctionMarioTheme_T1Interrupt(void)
{
    static int i = 0;

    PWM_SetFreq(note[i++]); // On joue chaque note
    if (i > NBNOTE) PWM_SetDutyCycle(0); // On stop tout quand c'est fini
}

void __attribute__((interrupt,no_auto_psv)) _T1Interrupt(void)
{
    static int d = 500;

    if (ISOFF)
    {
        // Si demande d'arret, on colle le mobile
        PWM_SetDutyCycle(d--);
        MODE1 = 1;
        MODE2 = 0;
        // lorsque le mobile est coll�, on lance un musique de mario
        if (d < 0) 
        {    
            d = 0;
            PR1=4000;                 // pour une p�riode de timer1 : 0,5s
            fonctionMarioTheme_T1Interrupt();
        }
    }
    else
    {   
        if (ISNUMERIC)
        {
            fonctionNumerique_T1Interrupt();
        }
        else
        {
            fonctionAnalog_T1Interrupt();
        } 
    }
    IFS0bits.T1IF = 0; //Reset Timer1 interrupt flag and Return from ISR
}

